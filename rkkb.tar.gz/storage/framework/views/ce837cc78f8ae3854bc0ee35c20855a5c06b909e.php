<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <!-- Collapsed Hamburger -->
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- Branding Image -->
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php echo e(config('app.name', 'Laravel')); ?>

            </a>
        </div>

        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <!-- Left Side Of Navbar -->
            <ul class="nav navbar-nav">
                <li><router-link to="/dashboard"><i class="fa fa-tachometer"></i> Dashboard</router-link></li>
                <li><router-link to="/contracts"><i class="fa fa-file"></i> Contracts</router-link></li>
                <li><router-link to="/allocation"><i class="fa fa-truck"></i> Truck Allocations</router-link></li>




            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                        <i class="fa fa-lock"></i> Administration <span class="caret"></span>
                    </a>

                    <ul class="dropdown-menu" role="menu">
                        <li><router-link to="/drivers"><i class="fa fa-users"></i> Drivers</router-link></li>
                        <li><router-link to="/routes"><i class="fa fa-road"></i> Routes</router-link></li>
                        <li><router-link to="/trucks"><i class="fa fa-truck"></i> Trucks</router-link></li>
                        

                    </ul>
                </li>
                <!-- Authentication Links -->
                <?php if(Auth::guest()): ?>
                    
                    
                <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

